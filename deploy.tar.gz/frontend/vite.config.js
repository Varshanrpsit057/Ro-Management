import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    port: 3057,
    host: true,
    proxy: {
      "/api": {
        target: "http://localhost:8057",
        changeOrigin: true,
      },
    },
  },
});
